"""Acquire and freeze 40 available annotated RGBs per video, without model outputs."""
import io
import json
import hashlib
import re
import tarfile
import zipfile
from pathlib import Path
import requests
from select_epic_diagnostic import iter_annotations

WORK = Path.home() / 'cv_project'
ROOT = WORK / 'data_compare200'
VIDEOS = ['P01_01', 'P02_03', 'P03_04', 'P08_09', 'P22_01']
POSE_URL = 'https://thor.robots.ox.ac.uk/epic-fields/json-format.tar.gz'
TARGETS = {'pan','pot','saucepan','cup','mug','bowl','plate','knife','fork','spoon','spatula','lid','bottle','container','box','chopping board','cutting board','grater','peeler','scissors','can','jar','package','jug','kettle','glass','tray','colander','sieve','ladle','tongs'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def download(url, path):
    if path.exists():
        return
    temp = path.with_suffix(path.suffix + '.partial')
    with requests.get(url, stream=True, timeout=(25, 90)) as response:
        response.raise_for_status()
        with temp.open('wb') as out:
            for block in response.iter_content(1024*1024):
                out.write(block)
    temp.replace(path)


def main():
    ROOT.mkdir(exist_ok=True)
    mappings = json.loads((ROOT / 'mappings.json').read_text())
    needed = {v for v in VIDEOS if not (ROOT / v / 'fields.json').exists()}
    if needed:
        print('POSE_STREAM_START', sorted(needed), flush=True)
        # Stream the official archive, retaining only the requested JSONs.
        # Avoid storing the 7.5 GB archive or extracting unrelated videos.
        with requests.get(POSE_URL, stream=True, timeout=(25, 120)) as response:
            response.raise_for_status()
            response.raw.decode_content = True
            with tarfile.open(fileobj=response.raw, mode='r|gz') as archive:
                for member in archive:
                    video = Path(member.name).stem
                    if not member.isfile() or not member.name.endswith('.json') or video not in needed:
                        continue
                    folder = ROOT / video
                    folder.mkdir(exist_ok=True)
                    content = archive.extractfile(member).read()
                    parsed = json.loads(content)
                    assert 'camera' in parsed and 'images' in parsed
                    (folder / 'fields.json').write_bytes(content)
                    needed.remove(video)
                    print('POSE_SAVED', video, len(content), flush=True)
                    if not needed:
                        break
        if needed:
            raise RuntimeError(f'Poses missing: {needed}')
    old = set(json.loads((ROOT / 'old_p01_frames.json').read_text()))
    manifest = {'videos':VIDEOS, 'frames_per_video':40, 'source_pose_archive':POSE_URL,
                'frame_rule':'40 temporal quantiles of eligible RGB/mask/pose matches recovered from a fixed tar prefix; all previous 19 P01 frames excluded; no model output used',
                'category_rule':'Exact category or category containing a whole target noun; retain all candidates, rasterized mask >=128 pixels in inference audit',
                'target_nouns':sorted(TARGETS), 'minimum_mask_pixels':128,
                'limitations':'Availability sampling in five train videos; dependent frames and objects. No complete 3D ground truth; not final tracking test.', 'selected':[]}
    progress = ROOT/'selection_progress.json'
    completed = {v['video']:v for v in json.loads(progress.read_text())['selected']} if progress.exists() else {}
    for video in VIDEOS:
        folder = ROOT / video
        if video in completed:
            record=completed[video]
            assert len(record['frames'])==40
            assert all(sha(folder/'ready'/f['rgb_frame'])==f['rgb_sha256'] for f in record['frames'])
            manifest['selected'].append(record)
            print('SAMPLE_REUSED',video,40,flush=True)
            continue
        fields = json.loads((folder/'fields.json').read_text())
        rgb_url = f'https://data.bris.ac.uk/datasets/3h91syskeag572hl6tvuovwv4d/frames_rgb_flow/rgb/train/{video.split("_")[0]}/{video}.tar'
        zip_url = f'https://data.bris.ac.uk/datasets/2v6cgv1x04ol22qp9rm9x2j6a7/Interpolations-DenseAnnotations/train/{video}_interpolations.zip'
        zipped_path = folder/'annotations.zip'
        download(zip_url,zipped_path)
        # Prefix availability is fixed before inference; never extend based on model quality.
        size = 16*1024*1024
        prefix = folder/'rgb_prefix.bin'
        if not prefix.exists():
            if requests.head(rgb_url,timeout=(25,30)).status_code==404:
                for split in ['val','test']:
                    candidate=rgb_url.replace('/rgb/train/',f'/rgb/{split}/')
                    if requests.head(candidate,timeout=(25,30)).status_code==200:
                        rgb_url=candidate
                        break
            with requests.get(rgb_url, headers={'Range':f'bytes=0-{size-1}'}, stream=True, timeout=(25,90)) as response:
                response.raise_for_status()
                if response.status_code != 206:
                    raise RuntimeError('RGB server ignored bounded Range request')
                with prefix.open('wb') as out:
                    for block in response.iter_content(1024*1024):
                        out.write(block)
        recovered = {}
        blob = prefix.read_bytes()
        with tarfile.open(fileobj=io.BytesIO(blob), mode='r:') as archive:
            try:
                for member in archive:
                    if member.isfile() and member.name.lower().endswith('.jpg') and member.offset_data+member.size <= len(blob):
                        recovered[Path(member.name).name] = blob[member.offset_data:member.offset_data+member.size]
            except tarfile.ReadError:
                pass
        matches = {}
        with zipfile.ZipFile(zipped_path) as archive:
            names = [n for n in archive.namelist() if n.endswith('.json')]
            assert len(names)==1
            with archive.open(names[0]) as stream:
                for entry in iter_annotations(io.TextIOWrapper(stream, encoding='utf-8')):
                    key = Path(entry['image']['name']).stem+'.jpg'
                    rgb = mappings[video].get(key)
                    if rgb not in recovered or rgb not in fields['images'] or (video=='P01_01' and rgb in old):
                        continue
                    candidates = [{'annotation_index':i, 'name':o['name'], 'id':o['id']} for i,o in enumerate(entry['annotations'])
                                  if any(re.search(r'(?<!\w)'+re.escape(t)+r'(?!\w)', o['name'].lower()) for t in TARGETS)]
                    if candidates and rgb not in matches:
                        matches[rgb] = (entry,candidates)
        ordered = sorted(matches)
        if len(ordered)<40:
            raise RuntimeError(f'{video}: only {len(ordered)} eligible RGBs; do not silently reduce sample')
        chosen = [ordered[round(i*(len(ordered)-1)/39)] for i in range(40)]
        ready = folder/'ready'
        ready.mkdir(exist_ok=True)
        frames,entries = [],[]
        for rgb in chosen:
            entry,candidates=matches[rgb]
            (ready/rgb).write_bytes(recovered[rgb])
            frames.append({'rgb_frame':rgb, 'rgb_sha256':sha(ready/rgb), 'visor_frame':entry['image']['name'],
                           'mapping_changes_index':rgb!=Path(entry['image']['name']).name.replace(video+'_','').replace('.png','.jpg'), 'candidates':candidates})
            entries.append(dict(entry,rgb_frame=rgb))
        (ready/'selection.json').write_text(json.dumps(dict(manifest,video=video,frames=frames),indent=2))
        (ready/'annotations.json').write_text(json.dumps({'video_annotations':entries}))
        (ready/'camera.json').write_text(json.dumps({'camera':fields['camera'],'images':{n:fields['images'][n] for n in chosen}}))
        metadata={'video':video,'eligible_before_selection':len(ordered),'recovered_jpegs':len(recovered),'frames':frames,
                  'pose_sha256':sha(folder/'fields.json'),'zip_sha256':sha(zipped_path),'rgb_prefix_sha256':sha(prefix),
                  'rgb_url':rgb_url,'annotation_url':zip_url,'rgb_bytes':[0,size-1]}
        manifest['selected'].append(metadata)
        (ROOT/'selection_progress.json').write_text(json.dumps(manifest,indent=2))
        print('SAMPLE_FROZEN',video,len(chosen),sum(len(f['candidates']) for f in frames),flush=True)
    (ROOT/'selection_final.json').write_text(json.dumps(manifest,indent=2))
    print('COMPARE200_ACQUISITION_OK',flush=True)


if __name__=='__main__':
    main()
