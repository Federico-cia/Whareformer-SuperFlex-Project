# Input compare200 per il collegamento a Whareformer

Contenuto: 200 RGB (40 per video), 299 maschere VISOR binarie e 598 nuvole originali: 299 DA grezzo, 299 MoGE. Cinque video: P01_01, P02_03, P03_04, P08_09, P22_01. Nessuna nuova inferenza.

- `data/compare200/`: copia degli input disponibili, inclusi `selection_final.json`, annotazioni e camera per video.
- `outputs/compare200_749968/`: maschere e nuvole nei percorsi originali, per preservare la provenienza.
- `observations_for_tracking.json`: corrispondenza esplicita fra osservazione, RGB, maschera e nuvole.
- `scripts/acquire_compare200.py`: script originale di acquisizione, conservato per riproducibilità; non occorre rieseguirlo per usare questi file. Rimane uno script storico, non il nuovo runner portabile.
- `SHA256.json`: checksum di tutti gli altri file del pacchetto.

Estrarre mantenendo la struttura. Le maschere PNG estratte non erano nella cartella input: erano negli output. `annotation_index` indica l'annotazione del frame, non un track ID; `annotation_id` non certifica un'identità persistente. Il collegamento alle detection e ai track reali rimane da verificare con Whareformer, includendo il mapping VISOR/RGB.

Ogni NPZ contiene `camera_points[N,3]`, `colors[N,3]`, `pixels_xy[N,2]`. Sono tutti i punti estratti disponibili, non i 1024 punti normalizzati usati per le distanze, né l'input SuperFlex normalizzato a 4096 punti. Assi camera: X destra, Y basso, Z avanti. DA è il ramo grezzo non allineato; MoGE conserva la propria scala stimata. Non mescolare i due rami come se condividessero una scala metrica certificata.

Per accumulare viste nel tempo serve registrazione in un riferimento comune dell'oggetto e gestione di scala, posa e movimento. La posa della camera da sola non allinea un oggetto che si muove; assegnare lo stesso track ID non risolve l'allineamento 3D. La fusione delle nuvole è un esperimento del collega riferito da Marco, non un metodo già implementato o validato nel componente consegnato.

Il pacchetto non include reti, pesi, mesh SuperFlex, profondità dense o credenziali. Codice portabile e risultati sono nella repository comune. I dati EPIC/VISOR restano soggetti alle condizioni delle fonti originali: condividere nel gruppo con accesso ai dati, senza ripubblicazione indiscriminata.
